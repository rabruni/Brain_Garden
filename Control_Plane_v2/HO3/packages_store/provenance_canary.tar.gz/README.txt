provenance canary
