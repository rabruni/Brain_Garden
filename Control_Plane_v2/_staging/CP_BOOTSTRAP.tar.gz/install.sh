#!/usr/bin/env bash
#
# install.sh — Control Plane v2 Bootstrap Installer
#
# Installs the full Layer 0-2 governance foundation from the package
# archives in this directory. Optionally installs Layer 3 packages.
#
# Usage:
#   ./install.sh --root <dir> [--dev] [--force] [--layer3 <pkg.tar.gz> ...]
#
# Arguments:
#   --root <dir>     Install target directory (required, created if absent)
#   --dev            Bypass auth/signature checks (for testing)
#   --force          Overwrite existing files (for re-install/recovery)
#   --layer3 <pkgs>  Additional package archives to install after bootstrap
#
# Prerequisites:
#   - python3 (3.10+, stdlib only — no pip packages needed)
#
# Exit codes:
#   0  Success
#   1  Missing prerequisites or argument error
#   2  Package install failure
#   3  Gate check failure

set -euo pipefail

# ── Constants ──────────────────────────────────────────────────────────

# Layer 0-2 install order (from bootstrap_sequence.json)
LAYER0_GENESIS="PKG-GENESIS-000"
LAYER0_KERNEL="PKG-KERNEL-001"
LAYER1_PACKAGES="PKG-VOCABULARY-001 PKG-REG-001"
LAYER2_PACKAGES="PKG-GOVERNANCE-UPGRADE-001 PKG-FRAMEWORK-WIRING-001 PKG-SPEC-CONFORMANCE-001 PKG-LAYOUT-001"

# Layer 3: validated application packages (schemas first, then budgeter, router, layout upgrade)
LAYER3_BUILTIN="PKG-PHASE2-SCHEMAS-001 PKG-TOKEN-BUDGETER-001 PKG-PROMPT-ROUTER-001 PKG-ANTHROPIC-PROVIDER-001 PKG-LAYOUT-002"

# ── Helpers ────────────────────────────────────────────────────────────

info()  { echo "==> $*"; }
step()  { echo ""; echo "── Step $1: $2 ──"; }
err()   { echo "ERROR: $*" >&2; }
die()   { err "$*"; exit 1; }

# ── Argument parsing ──────────────────────────────────────────────────

ROOT=""
DEV_FLAG=""
FORCE_FLAG=""
LAYER3_ARCHIVES=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --root)
            [[ $# -lt 2 ]] && die "--root requires a directory argument"
            ROOT="$2"
            shift 2
            ;;
        --dev)
            DEV_FLAG="--dev"
            shift
            ;;
        --force)
            FORCE_FLAG="--force"
            shift
            ;;
        --layer3)
            shift
            while [[ $# -gt 0 && "$1" != --* ]]; do
                LAYER3_ARCHIVES+=("$1")
                shift
            done
            ;;
        -h|--help)
            echo "Usage: ./install.sh --root <dir> [--dev] [--force] [--layer3 <pkg.tar.gz> ...]"
            echo ""
            echo "  --root <dir>     Install target directory (required)"
            echo "  --dev            Bypass auth/signature checks"
            echo "  --force          Overwrite existing files (re-install)"
            echo "  --layer3 <pkgs>  Additional packages to install after bootstrap"
            exit 0
            ;;
        *)
            die "Unknown argument: $1 (use --help for usage)"
            ;;
    esac
done

[[ -z "$ROOT" ]] && die "--root is required. Usage: ./install.sh --root <dir> [--dev] [--force]"

# ── Prerequisites ─────────────────────────────────────────────────────

if ! command -v python3 &>/dev/null; then
    die "python3 is required but not found. Install Python 3.10+ and try again."
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
info "Using python3 $PYTHON_VERSION"

# ── Resolve paths ─────────────────────────────────────────────────────

# Directory containing this script
BOOTSTRAP_DIR="$(cd "$(dirname "$0")" && pwd)"
# Package archives live in packages/ subdirectory
PACKAGES_DIR="$BOOTSTRAP_DIR/packages"

# Resolve ROOT to absolute path
mkdir -p "$ROOT"
ROOT="$(cd "$ROOT" && pwd)"

export CONTROL_PLANE_ROOT="$ROOT"

info "Bootstrap dir: $BOOTSTRAP_DIR"
info "Install root:  $ROOT"
[[ -n "$DEV_FLAG" ]] && info "Dev mode:      ON"
[[ -n "$FORCE_FLAG" ]] && info "Force mode:    ON"

# ── Verify archives exist ────────────────────────────────────────────

check_archive() {
    local archive="$PACKAGES_DIR/$1.tar.gz"
    [[ -f "$archive" ]] || die "Missing archive: $archive"
}

[[ -d "$PACKAGES_DIR" ]] || die "Missing packages/ directory in $BOOTSTRAP_DIR. Expected: $PACKAGES_DIR"

check_archive "$LAYER0_GENESIS"
check_archive "$LAYER0_KERNEL"
for pkg in $LAYER1_PACKAGES $LAYER2_PACKAGES $LAYER3_BUILTIN; do
    check_archive "$pkg"
done

for archive in "${LAYER3_ARCHIVES[@]+"${LAYER3_ARCHIVES[@]}"}"; do
    [[ -f "$archive" ]] || die "Layer 3 archive not found: $archive"
done

info "All required archives present"

# ── Step 1: Extract genesis seed ──────────────────────────────────────

step 1 "Extract $LAYER0_GENESIS (bootstrap seed)"

tar xzf "$PACKAGES_DIR/$LAYER0_GENESIS.tar.gz" -C "$ROOT"

# Verify genesis files landed
[[ -f "$ROOT/HOT/scripts/genesis_bootstrap.py" ]] || die "genesis_bootstrap.py not found after extracting $LAYER0_GENESIS"
[[ -f "$ROOT/HOT/config/seed_registry.json" ]]    || die "seed_registry.json not found after extracting $LAYER0_GENESIS"

# Clean up top-level manifest.json left by tar extraction (not needed at root)
rm -f "$ROOT/manifest.json"

info "$LAYER0_GENESIS extracted: genesis_bootstrap.py + configs on disk"

# ── Step 2: Install Layer 0 (kernel via genesis bootstrap) ────────────

step 2 "Install $LAYER0_KERNEL (Layer 0 — genesis bootstrap)"

GENESIS_ARGS=(
    --seed "$ROOT/HOT/config/seed_registry.json"
    --archive "$PACKAGES_DIR/$LAYER0_KERNEL.tar.gz"
    --id "$LAYER0_KERNEL"
    --genesis-archive "$PACKAGES_DIR/$LAYER0_GENESIS.tar.gz"
)
[[ -n "$FORCE_FLAG" ]] && GENESIS_ARGS+=(--force)

python3 "$ROOT/HOT/scripts/genesis_bootstrap.py" "${GENESIS_ARGS[@]}"

# Verify package_install.py now exists
[[ -f "$ROOT/HOT/scripts/package_install.py" ]] || die "package_install.py not found after installing $LAYER0_KERNEL"

info "$LAYER0_KERNEL installed: package_install.py now available"

# ── Helper: install a package via package_install.py ──────────────────

install_package() {
    local archive="$1"
    local pkg_id="$2"

    local args=(
        --archive "$archive"
        --id "$pkg_id"
        --root "$ROOT"
    )
    [[ -n "$DEV_FLAG" ]] && args+=("$DEV_FLAG")
    [[ -n "$FORCE_FLAG" ]] && args+=("$FORCE_FLAG")

    python3 "$ROOT/HOT/scripts/package_install.py" "${args[@]}"
}

# ── Step 3: Install Layer 1 ──────────────────────────────────────────

step 3 "Install Layer 1 (vocabulary + registries)"

for pkg in $LAYER1_PACKAGES; do
    info "Installing $pkg..."
    install_package "$PACKAGES_DIR/$pkg.tar.gz" "$pkg"
done

# ── Step 4: Install Layer 2 ──────────────────────────────────────────

step 4 "Install Layer 2 (governance enforcement)"

for pkg in $LAYER2_PACKAGES; do
    info "Installing $pkg..."
    install_package "$PACKAGES_DIR/$pkg.tar.gz" "$pkg"
done

# ── Step 5: Install Layer 3 (built-in validated packages) ────────────

step 5 "Install Layer 3 (application packages)"

for pkg in $LAYER3_BUILTIN; do
    info "Installing $pkg..."
    install_package "$PACKAGES_DIR/$pkg.tar.gz" "$pkg"
done

# ── Step 6: Install additional packages (optional, via --layer3) ─────

if [[ ${#LAYER3_ARCHIVES[@]} -gt 0 ]]; then
    step 6 "Install additional packages (${#LAYER3_ARCHIVES[@]} extra)"

    for archive in "${LAYER3_ARCHIVES[@]}"; do
        # Resolve to absolute path
        if [[ "$archive" != /* ]]; then
            archive="$(cd "$(dirname "$archive")" && pwd)/$(basename "$archive")"
        fi
        pkg_file=$(basename "$archive")
        pkg_id="${pkg_file%.tar.gz}"
        info "Installing $pkg_id..."
        install_package "$archive" "$pkg_id"
    done
fi

# ── Gate checks ──────────────────────────────────────────────────────

GATE_STEP=$([[ ${#LAYER3_ARCHIVES[@]} -gt 0 ]] && echo 7 || echo 6)

step "$GATE_STEP" "Running gate checks"

GATE_OUTPUT=$(python3 "$ROOT/HOT/scripts/gate_check.py" --root "$ROOT" --all 2>&1) || true
echo "$GATE_OUTPUT"

# Count passes/failures from gate summary lines (G??: PASS or G??: FAIL)
PASS_COUNT=$(echo "$GATE_OUTPUT" | grep -cE '^G[0-9A-Z]+: PASS' || true)
FAIL_COUNT=$(echo "$GATE_OUTPUT" | grep -cE '^G[0-9A-Z]+: FAIL' || true)

# ── Summary ───────────────────────────────────────────────────────────

echo ""
echo "════════════════════════════════════════════════════════════"
echo "  Control Plane v2 Bootstrap Complete"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "  Root:          $ROOT"
echo "  Layer 0:       $LAYER0_KERNEL"
echo "  Layer 1:       $(echo $LAYER1_PACKAGES | tr ' ' ', ')"
echo "  Layer 2:       $(echo $LAYER2_PACKAGES | tr ' ' ', ')"
echo "  Layer 3:       $(echo $LAYER3_BUILTIN | tr ' ' ', ')"
if [[ ${#LAYER3_ARCHIVES[@]} -gt 0 ]]; then
    L3_NAMES=""
    for a in "${LAYER3_ARCHIVES[@]}"; do
        name=$(basename "$a")
        L3_NAMES="${L3_NAMES:+$L3_NAMES, }${name%.tar.gz}"
    done
    echo "  Extra:         $L3_NAMES"
fi
echo "  Gates:         $PASS_COUNT passed, $FAIL_COUNT failed"
echo ""

# Count installed receipts
RECEIPT_COUNT=$(ls -d "$ROOT/HOT/installed"/PKG-*/receipt.json 2>/dev/null | wc -l | tr -d ' ')
echo "  Receipts:      $RECEIPT_COUNT packages in HOT/installed/"
echo ""

if [[ "$FAIL_COUNT" -gt 0 ]]; then
    echo "  WARNING: $FAIL_COUNT gate failure(s). Review output above."
    exit 3
fi

echo ""
echo "  Install successful."
echo ""
