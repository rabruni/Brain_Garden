# Control Plane v2 Bootstrap

## Install

```bash
chmod +x install.sh
./install.sh --root /path/to/install --dev
```

This installs 12 packages across 4 layers. Takes ~10 seconds. Requires Python 3.10+ (stdlib only, no pip).

Do NOT install packages manually. The install order matters and install.sh handles it.

## Install with Layer 3 packages

If you have additional .tar.gz package archives, install them in one command:

```bash
./install.sh --root /path/to/install --dev \
    --layer3 PKG-PHASE2-SCHEMAS-001.tar.gz \
             PKG-TOKEN-BUDGETER-001.tar.gz \
             PKG-PROMPT-ROUTER-001.tar.gz
```

Layer 3 order matters: schemas first, then budgeter, then router.

## Verify

```bash
python3 /path/to/install/HOT/scripts/gate_check.py --root /path/to/install --all
```

Expected: 8/8 gates PASS.

## Flags

| Flag | Description |
|------|-------------|
| `--root <dir>` | Install directory (required, created if absent) |
| `--dev` | Bypass auth checks (use for testing) |
| `--force` | Overwrite existing files (re-install/recovery) |
| `--layer3 <archives...>` | Additional packages to install after bootstrap |

## What's inside this archive

```
README.md        <-- You are here
INSTALL.md       <-- Detailed manual guide + troubleshooting
install.sh       <-- Run this to install
packages/        <-- Package archives (do not extract manually)
  PKG-GENESIS-000.tar.gz            Layer 0: bootstrap seed
  PKG-KERNEL-001.tar.gz             Layer 0: kernel primitives
  PKG-VOCABULARY-001.tar.gz         Layer 1: governance vocabulary
  PKG-REG-001.tar.gz                Layer 1: registries
  PKG-GOVERNANCE-UPGRADE-001.tar.gz Layer 2: governance enforcement
  PKG-FRAMEWORK-WIRING-001.tar.gz   Layer 2: frameworks + schemas
  PKG-SPEC-CONFORMANCE-001.tar.gz   Layer 2: spec conformance
  PKG-LAYOUT-001.tar.gz             Layer 2: tier layout
  PKG-PHASE2-SCHEMAS-001.tar.gz     Layer 3: phase 2 schemas
  PKG-TOKEN-BUDGETER-001.tar.gz     Layer 3: token budgeting
  PKG-PROMPT-ROUTER-001.tar.gz      Layer 3: prompt routing
  PKG-LAYOUT-002.tar.gz             Layer 3: layout upgrade
```

## Do not

- Do NOT extract or install packages from `packages/` manually. Use `install.sh`.
- Do NOT skip `--dev` unless you have HMAC auth configured.
- Do NOT edit installed files. Use the package system to ship changes.

## Detailed guide

See `INSTALL.md` for manual step-by-step install, troubleshooting, and architecture overview.
