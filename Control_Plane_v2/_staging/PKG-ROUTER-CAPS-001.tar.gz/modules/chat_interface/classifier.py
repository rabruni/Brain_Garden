"""Query Extraction Helpers.

Extraction-only utilities for pulling structured data (directory paths,
file paths, package IDs, search patterns) from natural language queries.

Classification has been moved to the LLM router (modules.router).

Example:
    from modules.chat_interface.classifier import extract_dir_path, extract_file_path

    dir_path = extract_dir_path("what is in the modules directory?")
    # Returns "modules"
"""

import re
from typing import Optional


# Known directory names in Control Plane
KNOWN_DIRS = {
    "modules", "lib", "scripts", "config", "registries",
    "frameworks", "ledger", "specs", "schemas", "tests",
    "governed_prompts", "packages_store", "installed",
    "planes", "handlers", "templates", "versions",
    "_staging", "_external_quarantine", "docs",
}


def extract_dir_path(query: str) -> Optional[str]:
    """Extract directory path from query.

    Uses multiple strategies:
    1. Pattern matching for explicit directory references
    2. Known directory name detection
    3. Path-like string extraction

    Args:
        query: User query string

    Returns:
        Extracted directory path or None
    """
    query_lower = query.lower().strip()

    # Strategy 1: Pattern matching
    patterns = [
        r"what(?:'s| is) in (?:the )?(\w+)",
        r"list (?:files )?(?:in )?(\w+)",
        r"contents? of (?:the )?(\w+)",
        r"browse (\w+)",
        r"^ls (\w+)",
        r"show (?:me )?(?:the )?(\w+)\s*(?:directory|folder)?$",
    ]

    for pattern in patterns:
        match = re.search(pattern, query_lower)
        if match:
            candidate = match.group(1)
            # Verify it's a known directory or a path-like string
            if candidate in KNOWN_DIRS or "/" in candidate:
                return candidate
            # Check if any known dir is in the candidate
            if candidate in {"the", "a", "all", "some"}:
                continue
            return candidate

    # Strategy 2: Find known directory names in query
    for dir_name in KNOWN_DIRS:
        if dir_name in query_lower:
            # Make sure it's a word boundary match
            if re.search(rf"\b{dir_name}\b", query_lower):
                return dir_name

    # Strategy 3: Path-like string
    path_match = re.search(r"([\w/.-]+/[\w/.-]*)", query)
    if path_match:
        return path_match.group(1).rstrip("/")

    return None


def extract_file_path(query: str) -> Optional[str]:
    """Extract file path from query.

    Args:
        query: User query string

    Returns:
        Extracted file path or None
    """
    # Look for file paths with extensions
    patterns = [
        r"([\w/.-]+\.(?:py|md|json|csv|yaml|yml|txt|jsonl))",
        r"(lib/[\w/.-]+)",
        r"(scripts/[\w/.-]+)",
        r"(modules/[\w/.-]+)",
        r"(config/[\w/.-]+)",
        r"(registries/[\w/.-]+)",
        r"(frameworks/[\w/.-]+)",
        r"(ledger/[\w/.-]+)",
    ]

    for pattern in patterns:
        match = re.search(pattern, query, re.IGNORECASE)
        if match:
            return match.group(1)

    return None


def extract_package_id(query: str) -> Optional[str]:
    """Extract package ID from query.

    Args:
        query: User query string

    Returns:
        Package ID (PKG-...) or None
    """
    match = re.search(r"(PKG-[\w-]+)", query, re.IGNORECASE)
    if match:
        return match.group(1).upper()
    return None


def extract_search_pattern(query: str) -> Optional[str]:
    """Extract search pattern from query.

    Args:
        query: User query string

    Returns:
        Search pattern or None
    """
    # Remove common prefix words
    query = re.sub(r"^(?:search|grep|find)\s+(?:for\s+)?", "", query.lower())
    # Remove quotes
    query = query.strip("'\"")
    # Remove trailing context
    query = re.sub(r"\s+(?:in|across|within)\s+.*$", "", query)
    return query if query else None
