# KERNEL_PHASE_2.md — Section-by-Section Review

**Purpose**: Go through every section of KERNEL_PHASE_2.md, state what Claude understands the current position to be, get Ray's correction, then use this as the edit plan. This file is the source of truth for what to change — not the conversation.

**Status**: IN PROGRESS — Claude's understanding stated, awaiting Ray's review per section.

---

## Section 1: Header + Context (lines 1-14)

**What it says**: Status "Planning — Stage 1 in progress, Stage 1.5 next." Origin: live conversation during CP_BOOTSTRAP fixes.

**Claude's understanding**: Stages are superseded by the handoff sequence (HANDOFF-13 through 17). The stage model was useful for getting here but the semantic architecture plan replaced it with concrete packages and handoffs.

**Proposed action**: Update status to REFERENCE. Add date, supersession note pointing to semantic plan for implementation.

**Ray says**: _pending_

---

## Section 2: "Where We Actually Are" (lines 17-28)

**What it says**: "We have a package management system with integrity verification. That's it." 8 packages, 72 files, no agents, `--dev` mode only.

**Claude's understanding**: This was accurate on Feb 10. Now: 16 packages, 91+ files, ADMIN first boot achieved, cognitive dispatch designed, Session Host v1 running (flat loop). We're past "no agents" — ADMIN exists.

**Proposed action**: Update the numbers and the narrative to reflect current state.

**Ray says**: _pending_

---

## Section 3: "What the Kernel Has Today" (lines 32-47)

**What it says**: Table of Phase 1 components (auth, integrity, ledger, gates, etc.). "72 files governed. 8 packages. 133 tests passing."

**Claude's understanding**: All of this is done and still accurate as capabilities. The numbers are stale. The table itself is correct — these components exist and work.

**Proposed action**: Update numbers only. Table stays.

**Ray says**: _pending_

---

## Section 4: Biological Kernel Stack (lines 50-66)

**What it says**: 7-layer mapping (Boundary, Homeostasis, Sensation+Routing, Memory, Error detection, Valence, Self-model) with biology/CS/CP equivalents and status.

**Claude's understanding**: This framework is still valid and foundational. Status column needs updating (some "Missing" items are now "Partial" or "Done"). The bio mapping itself doesn't change.

**Proposed action**: Update status column only.

**Ray says**: _pending_

---

## Section 5: Three Kernel Gaps (lines 68-120)

**What it says**: Gap 1 (Attention Routing), Gap 2 (Self-Model), Gap 3 (Valence/Priority). Each with CS view, biology view, and design.

**Claude's understanding**:
- Gap 1 (Attention): PKG-ATTENTION-001 built. Being folded into HO2 per semantic plan. Pipeline design from this section still valid as theory.
- Gap 2 (Self-Model): am_i_intact(), what_am_i(), what_is_ungoverned() — all exist as G0B. Done.
- Gap 3 (Valence): Still missing. Future work.

**Proposed action**: Update status notes. Theory stays. Add pointers to where each gap was addressed.

**Ray says**: _pending_

---

## Section 6: Roadmap — Stage 0→1→1.5→2→3 (lines 123-165)

**What it says**: Four stages refined to: Boot → Kernel Running → Agent Definition → First Governed Agent → TBD. With adversarial findings.

**Claude's understanding**: This stage model is superseded by the semantic architecture plan's handoff sequence (FMWK-008→011 then HANDOFF-13→17). The stages were the right thinking at the time but the concrete plan replaced them.

**Proposed action**: Mark as superseded. Keep for historical context. Point to semantic plan.

**Ray says**: _pending_

---

## Section 7: Stage 0 + Stage 1 (lines 166-184)

**What it says**: Stage 0 done. Stage 1 deliverables: G0B, auth wiring, rebuild_derived_registries, self-verification, runtime artifact allowlist.

**Claude's understanding**: All done through bootstrap + follow-up handoffs.

**Proposed action**: Mark as DONE with pointers to which handoffs delivered each item.

**Ray says**: _pending_

---

## Section 8: Stage 1.5 — Agent Classes (lines 186-272)

**What it says**: Four classes defined: KERNEL.syntactic (brainstem), KERNEL.semantic (thalamus — 4 services including Flow Runner), ADMIN (prefrontal), RESIDENT (cortex). The Stack diagram. 6 architectural invariants.

**Claude's understanding**:
- KERNEL.syntactic: Still valid. Deterministic. Gates, hashing, integrity, auth.
- KERNEL.semantic: Concept absorbed into tier model (Feb 12). The 4 services listed:
  - Prompt Router — DONE, lives in HOT/kernel/
  - Attention — DONE (v1), being folded into HO2
  - Flow Runner — **SUPERSEDED** by HO2 Supervisor + HO1 Executor
  - Core Learning — Future (Stage 3+)
- ADMIN: Still valid. Governed chatbot. HO2 creates work orders, HO1 executes.
- RESIDENT: Still valid concept. Future.
- Stack diagram: Still valid conceptually.
- 6 invariants: Still valid. Need to add #7 (reading up vs calling through).

**Claude's recommendation on KERNEL.semantic**: Drop the label. It grouped 4 services — 2 are gone (Flow Runner superseded, Core Learning is research). What remains (prompt router, provider, budgeter) is already grouped by location (`HOT/kernel/`) and function (infrastructure services). The semantic plan doesn't use the term and is clearer for it. Keep the components, drop the class name.

**Proposed action**: Remove Flow Runner from the services list. Replace "KERNEL.semantic" with "HOT infrastructure services" or just name the actual components. Add invariant #7 (syscall principle). Keep everything else.

**Ray says**: _pending_

---

## Section 9: Agent Definition — Remaining Questions + Adversarial (lines 274-343)

**What it says**: 6 remaining questions about agents. 3-pass adversarial analysis. Synthesis with "what to build for Stage 2" and "what to defer."

**Claude's understanding**:
- Most questions answered by FMWK-008 and semantic plan.
- Adversarial findings were valuable — they drove the semantic plan's design.
- "What to defer" list is still accurate (core learning, graduated trust, provider failover — all still deferred).

**Proposed action**: Update questions with answers and pointers. Mark adversarial synthesis as "these conclusions drove the semantic plan." Keep deferrals.

**Ray says**: _pending_

---

## Section 10: Existing Infrastructure Inventory (lines 346-414)

**What it says**: Table of 14 existing components (LedgerFactory, LedgerClient, IsolatedWorkspace, CursorManager, Pristine, IntegrityChecker, etc.) with how they support agents. Plus "What's NOT Built" gap list.

**Claude's understanding**: This describes pre-bootstrap code from the conflated repo. Some of it was rebuilt into packages (ledger_client, integrity, auth, gates). Some exists but wasn't packaged. The "NOT Built" list has been partially addressed (prompt router done, work order schema in progress, prompt contract schema planned).

**Claude checked — here's what's in the bootstrap vs conflated repo:**

| Component | In Bootstrap? | Where |
|---|---|---|
| LedgerFactory (617 lines) | **NO** | Conflated repo only |
| LedgerClient | **YES** | PKG-KERNEL-001 (simpler than conflated version) |
| IsolatedWorkspace | **NO** | Conflated repo only |
| CursorManager | **NO** | Conflated repo only |
| Pristine enforcement | **YES** | PKG-KERNEL-001 |
| IntegrityChecker | **YES** | PKG-KERNEL-001 |
| Provenance/Attestation | **YES** | PKG-KERNEL-001 |
| GateOperations | **YES** | PKG-KERNEL-001 |
| Version management | **NO** | Conflated repo only |
| TierManifest | **YES** | PKG-KERNEL-001 |
| Registry operations | **YES** | PKG-REG-001 |
| ID allocator | **NO** | Conflated repo only |

About half shipped in the bootstrap. The other half (LedgerFactory, workspace, cursor, version mgmt, ID allocator) only exists in the conflated repo. The inventory describes a mix of shipped code and unshipped code.

**Proposed action**: Keep the inventory but add a "Shipped?" column so future readers know what's real vs aspirational. Mark which items are in bootstrap packages and which are conflated-repo-only.

**Ray says**: _pending_

---

## Section 11: Stage 2 — First Governed Agent (lines 418-503)

**What it says**: What gets built (work order schema, prompt contract schema, prompt router, one contract, one ADMIN agent). What gets reused. The 11-step flow. Scope boundaries. Done-when criteria.

**Claude's understanding**: Superseded by the semantic architecture plan's 5-package plan. The thinking here evolved into the concrete handoff sequence.

**Proposed action**: Mark as superseded. Point to semantic plan.

**Ray says**: _pending_

---

## Section 12: CS Kernel Comparison (lines 506-523)

**What it says**: Classical OS kernel vs agentic kernel comparison. What agentic kernels need that classical don't (non-determinism, provenance, resource accounting, self-inspection).

**Claude's understanding**: Still valid theory. Good reference.

**Proposed action**: Keep as-is.

**Ray says**: _pending_

---

## Section 13: Conversation Records (lines 526-559)

**What it says**: Session 1 and 2 summaries from Feb 10.

**Claude's understanding**: Historical record. Accurate for when it was written.

**Proposed action**: Keep as-is. It's history.

**Ray says**: _pending_

---

## Section 14: Outstanding Questions (lines 562-573)

**What it says**: Q1-Q7 with status and answers.

**Claude's understanding**:
- Q1 (kernel verify itself?): Answered — G0B exists
- Q2 (G0B timing?): Answered — both install-time and on-demand
- Q3 (InstallerClaims?): Answered — state-gated in KERNEL-001
- Q4 (What is an agent?): Answered — semantic plan + FMWK-008
- Q5 (End state?): Partially answered — cognitive dispatch model
- Q6 (Govern agents not files?): Answered — work orders + FMWK-008
- Q7 (Resource/cost model?): Partially answered — token budgeter exists, per-WO budgets in FMWK-008

**Proposed action**: Update each with current answer and pointer.

**Ray says**: _pending_

---

## Section 15: Install Lifecycle Design Decision (lines 574-651)

**What it says**: The missing post-install phase. Corrected lifecycle. State-gated design. file_ownership.csv schema. Rollback design.

**Claude's understanding**: All of this was implemented via HANDOFF-2 (Install Lifecycle). The design decision stands — it's how the system works.

**Proposed action**: Mark as DONE/IMPLEMENTED. Keep the design rationale — it's the "why" behind the install system.

**Ray says**: _pending_

---

## Section 16: Prior Art Survey (lines 654-810)

**What it says**: BaseAgent contract, capability matrix, firewall model, memory model, mandates as work orders, shaper, prompt contracts, dual validation, three-layer cognitive stack, patterns to carry forward, patterns NOT carrying forward.

**Claude's understanding**: Valuable reference material. The patterns we carried forward (prompts as contracts, ledger as sole memory, work orders as mandates, exchange recording, capability matrix) are all reflected in the semantic plan and FMWK-008. Still useful to have the source documented.

**Proposed action**: Keep as-is. This is reference material that doesn't go stale.

**Ray says**: _pending_

---

## Section 17: Memory Model Reframe — HOT = Highest Order Thought (lines 854-907)

**What it says**: Tiers are memory layers (HO1=fast, HO2=session, HOT=meta/abstract). HOT→HO2→HO1 chaining. "Agents don't REMEMBER, they READ." Tier-agent interaction. Flow Runner reads frameworks and instantiates agents. DoPeJar flow example.

**Claude's understanding**: This is WHERE the tier model comes from. Foundational. Still valid except:
- Flow Runner reference (line 876) needs updating to "HO2 Supervisor"
- DoPeJar flow (lines 878-907) references Flow Runner — update to HO2/HO1 dispatch
- We've since added the "reading up vs calling through" principle
- We've established HOTm/HO2m/HO1m naming convention (m = memory, without m = agent)

**Proposed action**: Update Flow Runner refs. Add syscall principle. Keep everything else — this is the foundation.

**Ray says**: _pending_

---

## Section 18: Attention Deep Dive (lines 911-1098)

**What it says**: Prior art (locked system 10-layer pipeline, HRM neural architecture). Six patterns from HRM. Memory tier mapping. Synthesis: attention is a pipeline of 4 decisions. 6 design constraints. Stage 2 plan (config-driven templates). 3-pass adversarial analysis.

**Claude's understanding**: Valuable future reference. The practical decision (attention folded into HO2, config-driven) was made in the semantic plan. The theory here (pipeline design, HRM mapping, design constraints, adversarial findings) is still valid for when we build the real attention system.

**Proposed action**: Keep as-is. Add note: "Practical implementation decided in SEMANTIC_ARCHITECTURE_PLAN.md — attention folded into PKG-HO2-SUPERVISOR-001."

**Ray says**: _pending_

---

## Section 19: Bottom-Up Signal Emergence (lines 1122-1175)

**What it says**: Attention emerges bottom-up from repeated useful activity. Weight vs authority firewall. Analogies (Hebbian, common law, immune system, PageRank). Risks.

**Claude's understanding**: Stage 3+ theory. Not current work. Valuable concept for future learning loops.

**Proposed action**: Keep as-is. This is future theory.

**Ray says**: _pending_

---

## Section 20: Ledger Entry Schema + Three Learning Loops (lines 1182-1295)

**What it says**: 6 field groups for ledger entries (provenance chain, relational links, context fingerprint, outcome linkage, scope tags). Three loops (HO2 operational, HOT governance, Meta). Signal vs noise discrimination.

**Claude's understanding**: Stage 3+ design. The ledger schema here is richer than what's currently implemented. The three learning loops map to HANDOFF-8 (Learning Loops — NOT DISPATCHED). Not current work but the design is solid.

**Claude checked — current vs proposed ledger entry fields:**

What EXISTS in LedgerEntry (PKG-KERNEL-001, ledger_client.py:104-118):
```
event_type, submission_id, decision, reason, prompts_used,
metadata (free-form dict), id (LED-{hex8}), timestamp,
previous_hash, entry_hash
```

What KERNEL_PHASE_2 PROPOSES (lines 1186-1238) — 6 rich field groups, ~20 fields:
- Provenance: agent_id, agent_class, framework_id, package_id, work_order_id, session_id
- Relational: parent_event_id, root_event_id, related_artifacts
- Context: context_hash, context_sources, prompt_contract_id, prompt, response, tokens_used
- Outcome: outcome, outcome_event_id
- Scope: tier, domain, event_category

**None of the proposed rich fields exist as formal fields.** They would go into `metadata` (the free-form dict). The current LedgerEntry is a simple generic record. The proposed schema is aspirational design for when agents run and learning loops exist. Valid design, entirely unimplemented.

**Proposed action**: Keep as-is with note: "This schema is the target for ledger entries when cognitive dispatch is running. Current LedgerEntry uses a generic metadata dict. These fields would be standardized metadata keys, not new dataclass fields."

**Ray says**: _pending_

---

## Summary of Actions

| Action | Sections |
|--------|----------|
| **Update status/numbers** | 1, 2, 3, 4, 5, 7, 14 |
| **Mark SUPERSEDED + pointer** | 6, 11 |
| **Update Flow Runner refs** | 8, 17 |
| **Add syscall principle** | 8 |
| **Keep as-is (valid theory)** | 12, 13, 16, 18, 19, 20 |
| **Mark DONE** | 15 |
| **TBD (needs Ray's input)** | 10 |

## Questions for Ray

1. **Section 8**: Is "KERNEL.semantic" still a useful label, or fully absorbed into "HOT infrastructure services"?
2. **Section 10**: Is the infrastructure inventory (LedgerFactory, workspace.py, cursor.py etc.) still relevant? Was any of it carried into bootstrap packages?
3. **Section 20**: Does the current ledger entry format include any of the rich fields (provenance chain, context fingerprint, outcome linkage), or is it all aspirational?
